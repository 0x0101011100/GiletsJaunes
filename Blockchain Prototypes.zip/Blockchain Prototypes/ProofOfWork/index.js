// Mining is a concept to proove you have put a lot of computing into making a block
// Avoiding spam

// npm install crypto-js --save
const SHA256 = require('crypto-js/sha256');

class Block {

	// Index (Block position, Creating Date of the Block, Every Data, Previous Block Hash, Current Block Hash
	constructor(index, timestamp, data, previousHash ='' ) {
		this.index = index;
		this.timestamp = timestamp;
		this.data = data;
		this.previousHash = previousHash;
		this.currentHash = this.calculateHash();
		this.nonce = 0; // Adding nonce value (random number
	}
	
	// Calculate Hash Function
	calculateHash() {
		return SHA256(this.index + this.previousHash + this.timestamp + JSON.stringify(this.data) + this.nonce).toString(); // Adding nonce to hash calculating
	}
	
	// Mining method w/ difficulty params	
	mineBlock(difficulty) {
		// Make the hash of the block begin w/ certain amount of 0
		while(this.currentHash.substring(0,difficulty) !== Array(difficulty + 1).join("0")) { // Make a string of 0 match the length difficulty
			this.nonce++; // incrementing nonce value since hash has enough 0
			this.currentHash = this.calculateHash(); // calculate the hash of this block
		}
		// Display the hash
		console.log("Block mined : " + this.currentHash); // NB : the hash of the block won't change if we don't change content of our block
	}
}

class Blockchain {

	constructor() {
		this.chain = [this.createGenesisBlock()]; // Blockchain initialized w/ 1st block of chain (The Genesis Block)
		this.difficulty = 4; // By increasing the value, you counterpart blockchain spam
	
	}

	// To create the 1st Block (Genesis Block of the Blockchain)
	createGenesisBlock() {
		return new Block(0,"01/01/1970","Genesis Block", "0");
	}
	
	// Getting latest block
	getLatestBlock() {
		return this.chain[this.chain.length-1];
	}
	
	// Add a new block
	addBlock(newBlock) {
		newBlock.previousHash = this.getLatestBlock().currentHash; // adding previous block hash to the new block
		newBlock.mineBlock(this.difficulty); // Mining new Block
		//newBlock.currentHash = newBlock.calculateHash(); // Calculate new hash for the new block
		this.chain.push(newBlock); // Adding this block to the blockchain
	}
	
	// To verify Blockchain integrity
	isChainValid() {
		for (let i=1; i<this.chain.length; i++) { // Not include the Genesis Block (Index : 0)
			
			const currentBlock = this.chain[i]; // Current Block grabbing
			const previousBlock = this.chain[i-1]; // Previous Block grabbing 

			// Verify the Current Block Hash value
			if (currentBlock.currentHash !== currentBlock.calculateHash()) {
				return false;
			}
		
			// Verify if the Current Block point correctly to the Previous Block
			if (currentBlock.previousHash !== previousBlock.currentHash) {
				return false;
			}
		}
		
		return true;
	}
}


// Feed the Blockchain
let demoBlockchain = new Blockchain();

// Mining Block#1
console.log("Mining Block#1");
demoBlockchain.addBlock(new Block(1,"23/12/2018", {value : 1}));

// Mining Block#2
console.log("Mining Block#2");
demoBlockchain.addBlock(new Block(2,"24/12/2018", {value : 2}));

// Verify if the Blockchain is valid
console.log("Is Blockchain valid ? " + demoBlockchain.isChainValid());

// Testing integrity of the Blockchain
//demoBlockchain.chain[1].data = {value:100};
//demoBlockchain.chain[1].currentHash = demoBlockchain.chain[1].calculateHash();
//console.log("Is Blockchain valid ? " + demoBlockchain.isChainValid());

// Display the Blockchain
console.log(JSON.stringify(demoBlockchain, null, 4));