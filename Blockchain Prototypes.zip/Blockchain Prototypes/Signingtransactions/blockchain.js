// Signing Transactions
// To generate Public & Private Key : use Keygenerator : node keygenerator.js & implement them in this codePointAt

// npm install crypto-js --save
const SHA256 = require('crypto-js/sha256');
// npm install elliptic --save
const EC = require("elliptic").ec; // Library for generating Private & Public Key
// Create EC
const ec = new EC('secp256k1'); // Algorithm basis on BTC Wallet

// Transaction class
class Transaction {
	// From, To, Value (ex : amount for instance)
	constructor(fromAddress, toAddress, value) {
		this.fromAddress = fromAddress;
		this.toAddress = toAddress;
		this.value = value;
	}
	
	// return the SHA-256 of the Transaction, which will be used to sign w/ our private Key
	calculateHash() { 
		return SHA256(this.fromAddress + this.toAddress + this.value).toString();
	}
	
	// To sign Transaction
	signTransaction(signingKey) { // signing key is from our Elliptic Library
	
		// Check if your public key equals the fromAddress
		if (signingKey.getPublic('hex') !== this.fromAddress) {
			throw new Error("You cannot sign Transaction for other Wallet");
		}
		
		const hashTransaction = this.calculateHash();
		const sig = signingKey.sign(hashTransaction, 'base64');
		this.signature = sig.toDER('hex'); // Store the signature into this Transaction
	}
	
	// To verify if our Transaction has been correctly signed
	isTransactionValid() {
		
		// Case of Mining reward
		if(this.fromAddress === null) return true; // fromAddress from Mining is null
		
		// Case of no or empty signature 
		if(!this.signature || this.signature.length === 0) {
			throw new Error("No Signature in this Transaction");
		}
		
		// Check that the Transaction has been signed w/ the correct Key (The fromAddress is a Public Key)
		const publicKey = ec.keyFromPublic(this.fromAddress, 'hex');
		
		// Verify that this block has been signed by this signature
		return publicKey.verify(this.calculateHash(), this.signature);
	}
}

// Block class
class Block {

	// Timestamp (Creating Date of the Block), Every Transactions, Previous Block Hash, Current Block Hash, Random number (Difficulty)
	constructor(timestamp, transactions, previousHash = '' ) {
		this.timestamp = timestamp;
		this.transactions = transactions;
		this.previousHash = previousHash;
		this.currentHash = this.calculateHash();
		this.nonce = 0; // Adding nonce value (random number)
	}
	
	// Calculate Hash Function
	calculateHash() {
		return SHA256(this.previousHash + this.timestamp + JSON.stringify(this.transactions) + this.nonce).toString(); // Adding nonce to hash calculating
	}
	
	// Mining method w/ difficulty params	
	mineBlock(difficulty) {
		
		// Make the hash of the block begin w/ certain amount of 0
		while(this.currentHash.substring(0,difficulty) !== Array(difficulty + 1).join("0")) { // Make a string of 0 match the length difficulty
			this.nonce++; // incrementing nonce value since hash has enough 0
			this.currentHash = this.calculateHash(); // calculate the hash of this block
		}
		
		// Display the hash
		console.log("Block mined : " + this.currentHash); // NB : the hash of the block won't change if we don't change content of our block
	}
	
	// To verify all the Transactions in a current Block
	hasValidTransactions() {
		for(const transaction of this.transactions) {
			
			// Check if each Transaction is valid
			if(!transaction.isTransactionValid()) {
				return false;
			}
		}
		
		return true;
	}
}

// Blockchain class
class Blockchain {

	constructor() {
		this.chain = [this.createGenesisBlock()]; // Blockchain initialized w/ 1st block of chain (The Genesis Block)
		this.difficulty = 2; // By increasing the value, you counterpart blockchain spam
		this.pendingTransactions = []; // Pending transaction Array
		this.miningReward = 100; // 100 is an example. To control how much coins the miners get as reward when a new block is successfully mined.
	}

	// To create the 1st Block (Genesis Block of the Blockchain)
	createGenesisBlock() {
		return new Block(Date.parse("1970-01-01"),[],"0");
	}
	
	// Getting latest block
	getLatestBlock() {
		return this.chain[this.chain.length-1];
	}
	
	// Mining Pending Transaction
	minePendingTransactions(miningRewardAddress) { // Pass in params the Mining Reward Address of the miner
		
		// Create New Reward Transaction
		const rewardTransaction = new Transaction(null, miningRewardAddress, this.miningReward);
		this.pendingTransactions.push(rewardTransaction);
		
		// Create New Block for Transaction
		let minedBlock = new Block(Date.now(), this.pendingTransactions, this.getLatestBlock().currentHash); // Create a new block w/ Current Date.
		minedBlock.mineBlock(this.difficulty); // Mining the created block
		
		console.log("Block successfully mined.");
		
		this.chain.push(minedBlock); // Adding Mined Block to the Blockchain
		
		// Reset the pending Transaction Array & Create a new Transaction for rewarding the next miner
		this.pendingTransactions = [
			//new Transaction(null, miningRewardAddress, this.miningReward)
		];
	}
	
	// Add Transaction to the Pending Transaction
	addTransaction(transaction) {
		
		// Check that fromAddress & toAddress are filled in
		if (!transaction.fromAddress || !transaction.toAddress) {
			throw new Error ("Transaction must include 'From & To' Address");
		}
		
		// Check that the Transaction is valid
		if (!transaction.isTransactionValid()) {
			throw new Error ("Cannot Add Invalid Transaction to the current Blockchain");
		}
		
		// All is ok, we push the current Transaction Array
		this.pendingTransactions.push(transaction);
	}
	
	// Check the Balance of an Address - NB : In reality, transaction are just stored on the Blockchain 
	getBalanceOfAddress(address) {
		let balance = 0;
		
		for (const Block of this.chain) { // We loop for each Block of the Blockchain
		
			for (const Transaction of Block.transactions) { // We loop for each Transaction of a Block
			
				if (Transaction.fromAddress === address) { // You are the Emitter of Transaction, so your Balance Decrease
					balance -= Transaction.value;
				}
				
				if (Transaction.toAddress === address) { // You are the Receiver of Transaction, so your Balance Increase
					balance += Transaction.value;
				}
			}
		}
		
		return balance; // Return calculated balance
	}
	
	// To verify Blockchain integrity 
	isChainValid() {
		for (let i=1; i<this.chain.length; i++) { // Not include the Genesis Block (Index : 0)
			
			const currentBlock = this.chain[i]; // Current Block grabbing
			const previousBlock = this.chain[i-1]; // Previous Block grabbing 
			
			// Verify that all Transaction in the current Block are valid
			if(!currentBlock.hasValidTransactions()) {
				return false;
			}

			// Verify the Current Block Hash value
			if (currentBlock.currentHash !== currentBlock.calculateHash()) {
				return false;
			}
		
			// Verify if the Current Block point correctly to the Previous Block
			if (currentBlock.previousHash !== previousBlock.currentHash) {
				return false;
			}
		}
		
		return true;
	}
}


// To use outside

module.exports.Blockchain = Blockchain;
module.exports.Transaction = Transaction;
