// npm install elliptic --save
const EC = require("elliptic").ec; // Library for generating Private & Public Key

// Create EC
const ec = new EC('secp256k1'); // Algorithm basis on BTC Wallet

// Generate Key
const key = ec.genKeyPair();
const publicKey = key.getPublic('hex');
const privateKey = key.getPrivate('hex');

// For testing
console.log();
console.log("Public Key : " + publicKey);
console.log();
console.log("Private Key : " + privateKey);