// Import Blochain & Transaction Class from Blockchain.js
const {Blockchain, Transaction} = require('./blockchain');
// npm install elliptic --save
const EC = require("elliptic").ec; // Library for generating Private & Public Key
// Create EC
const ec = new EC('secp256k1'); // Algorithm basis on BTC Wallet

// Implementing Private Key (Generate w/ keygenerator.js
const myPrivateKey = ec.keyFromPrivate('Your Private Key'); // Use Keygenerator.js to generate your Private Key
const myWalletAddress = myPrivateKey.getPublic('hex');

// Create the Blockchain
let demoBlockchain = new Blockchain();

// First Transaction from my own Wallet to a 'Fake Public Key' of someone else
const Transaction_1 = new Transaction(myWalletAddress,'fake public key', 10);

// Signing this First Transaction w/ my Private Key
Transaction_1.signTransaction(myPrivateKey);

// Adding to the Blockchain
demoBlockchain.addTransaction(Transaction_1);

// Start the Miner to create block theses pending transaction & store them in our Blockchain
console.log('Starting the Miner ...');
demoBlockchain.minePendingTransactions(myWalletAddress); // miningRewardAddress is sent to myWalletAddress which is my Public Key 

// Check the balance of my Wallet Address
console.log('Balance of my Wallet Address account is : ', demoBlockchain.getBalanceOfAddress(myWalletAddress));

// For testing Blockchain integrity
//demoBlockchain.chain[1].transactions[0].value = 1;

// To display Transactions
//console.log(demoBlockchain.chain[1]);

// Check if Blockchain is valid
console.log('Is Blockchain valid ? ', demoBlockchain.isChainValid());