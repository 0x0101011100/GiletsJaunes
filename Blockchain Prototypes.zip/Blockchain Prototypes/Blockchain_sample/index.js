// npm install crypto-js --save
const SHA256 = require('crypto-js/sha256');

class Block {

	// Index (Block position, Creating Date of the Block, Every Data, Previous Block Hash, Current Block Hash
	constructor(index, timestamp, data, previousHash ='' ) {
		this.index = index;
		this.timestamp = timestamp;
		this.data = data;
		this.previousHash = previousHash;
		this.currentHash = this.calculateHash();
	}
	
	// Calculate Hash Function
	calculateHash() {
		return SHA256(this.index + this.previousHash + this.timestamp + JSON.stringify(this.data)).toString();
	}
}

class Blockchain {
	
	constructor() {
		this.chain = [this.createGenesisBlock()] // Blockchain initialized w/ 1st block of chain (The Genesis Block)
	
	}

	// To create the 1st Block (Genesis Block of the Blockchain)
	createGenesisBlock() {
		return new Block(0,"01/01/1970","Genesis Block", "0");
	}
	
	// Getting latest block
	getLatestBlock() {
		return this.chain[this.chain.length-1];
	}
	
	// Add a new block
	addBlock(newBlock) {
		newBlock.previousHash = this.getLatestBlock().currentHash; // adding previous block hash to the new block
		newBlock.currentHash = newBlock.calculateHash(); // Calculate new hash for the new block
		this.chain.push(newBlock); // Adding this block to the blockchain
	}
	
	// To verify Blockchain integrity
	isChainValid() {
		for (let i=1; i<this.chain.length; i++) { // Not include the Genesis Block (Index : 0)
			
			const currentBlock = this.chain[i]; // Current Block grabbing
			const previousBlock = this.chain[i-1]; // Previous Block grabbing 

			// Verify the Current Block Hash value
			if (currentBlock.currentHash !== currentBlock.calculateHash()) {
				return false;
			}
		
			// Verify if the Current Block point correctly to the Previous Block
			if (currentBlock.previousHash !== previousBlock.currentHash) {
				return false;
			}
		}
		
		return true;
	}
}


// Feed the Blockchain
let demoBlockchain = new Blockchain();
demoBlockchain.addBlock(new Block(1,"23/12/2018", {value : 1}));
demoBlockchain.addBlock(new Block(2,"24/12/2018", {value : 2}));

// Verify if the Blockchain is valid
console.log("Is Blockchain valid ? " + demoBlockchain.isChainValid());

// Testing integrity of the Blockchain
//demoBlockchain.chain[1].data = {value:100};
//demoBlockchain.chain[1].currentHash = demoBlockchain.chain[1].calculateHash();
//console.log("Is Blockchain valid ? " + demoBlockchain.isChainValid());

// Display the Blockchain
console.log(JSON.stringify(demoBlockchain, null, 4));