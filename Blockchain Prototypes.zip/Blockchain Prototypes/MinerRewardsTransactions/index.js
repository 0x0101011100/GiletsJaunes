// Making a simple Crypto Currency Prototype

// npm install crypto-js --save
const SHA256 = require('crypto-js/sha256');

// Transaction class
class Transaction {
	// From, To, Value (amount for instance)
	constructor(fromAddress, toAddress, value) {
		this.fromAddress = fromAddress;
		this.toAddress = toAddress;
		this.value = value;
	}
}

// Block class
class Block {

	// Timestamp (Creating Date of the Block), Every Transactions, Previous Block Hash, Current Block Hash, Random number (Difficulty)
	constructor(timestamp, transactions, previousHash = '' ) {
		this.timestamp = timestamp;
		this.transactions = transactions;
		this.previousHash = previousHash;
		this.currentHash = this.calculateHash();
		this.nonce = 0; // Adding nonce value (random number)
	}
	
	// Calculate Hash Function
	calculateHash() {
		return SHA256(this.previousHash + this.timestamp + JSON.stringify(this.transactions) + this.nonce).toString(); // Adding nonce to hash calculating
	}
	
	// Mining method w/ difficulty params	
	mineBlock(difficulty) {
		// Make the hash of the block begin w/ certain amount of 0
		while(this.currentHash.substring(0,difficulty) !== Array(difficulty + 1).join("0")) { // Make a string of 0 match the length difficulty
			this.nonce++; // incrementing nonce value since hash has enough 0
			this.currentHash = this.calculateHash(); // calculate the hash of this block
		}
		// Display the hash
		console.log("Block mined : " + this.currentHash); // NB : the hash of the block won't change if we don't change content of our block
	}
}

// Blockchain class
class Blockchain {

	constructor() {
		this.chain = [this.createGenesisBlock()]; // Blockchain initialized w/ 1st block of chain (The Genesis Block)
		this.difficulty = 2; // By increasing the value, you counterpart blockchain spam
		this.pendingTransactions = []; // Pending transaction Array
		this.miningReward = 100; // 100 is an example. To control how much coins the miners get as reward when a new block is successfully mined.
	}

	// To create the 1st Block (Genesis Block of the Blockchain)
	createGenesisBlock() {
		return new Block("01/01/1970","Genesis Block", "0");
	}
	
	// Getting latest block
	getLatestBlock() {
		return this.chain[this.chain.length-1];
	}
	
	// Mining Pending Transaction
	minePendingTransactions(miningRewardAddress) { // Pass in params the Mining Reward Address of the miner
	
		let minedBlock = new Block(Date.now(), this.pendingTransactions); // Create a new block w/ Current Date.
		
		minedBlock.mineBlock(this.difficulty); // Mining the created block
		
		console.log("Block successfully mined.");
		
		this.chain.push(minedBlock); // Adding Mined Block to the Blockchain
		
		// Reset the pending Transaction Array & Create a new Transaction for rewarding the next miner
		this.pendingTransactions = [
			new Transaction(null, miningRewardAddress, this.miningReward)
		];
	}
	
	// Create Transaction & Add it to the Pending Transaction
	createTransaction(transaction) {
		this.pendingTransactions.push(transaction);
	}
	
	// Check the Balance of an Address - NB : In reality, transaction are just stored on the Blockchain 
	getBalanceOfAddress(address) {
		let balance = 0;
		
		for (const Block of this.chain) { // We loop for each Block of the Blockchain
		
			for (const Transaction of Block.transactions) { // We loop for each Transaction of a Block
			
				if (Transaction.fromAddress === address) { // You are the Emitter of Transaction, so your Balance Decrease
					balance -= Transaction.value;
				}
				
				if (Transaction.toAddress === address) { // You are the Receiver of Transaction, so your Balance Increase
					balance += Transaction.value;
				}
			}
		}
		
		return balance; // Return calculated balance
	}
	
	// To verify Blockchain integrity
	isChainValid() {
		for (let i=1; i<this.chain.length; i++) { // Not include the Genesis Block (Index : 0)
			
			const currentBlock = this.chain[i]; // Current Block grabbing
			const previousBlock = this.chain[i-1]; // Previous Block grabbing 

			// Verify the Current Block Hash value
			if (currentBlock.currentHash !== currentBlock.calculateHash()) {
				return false;
			}
		
			// Verify if the Current Block point correctly to the Previous Block
			if (currentBlock.previousHash !== previousBlock.currentHash) {
				return false;
			}
		}
		
		return true;
	}
}


// Create the Blockchain
let demoBlockchain = new Blockchain();

// Simulation creating Transaction stored in the Pending Transaction Array
// In reality, address1 & address2 are public address of someone wallet
demoBlockchain.createTransaction(new Transaction('address1', 'address2', 100));
demoBlockchain.createTransaction(new Transaction('address2', 'address1', 50));

// Start the Miner to create block theses pending transaction & store them in our Blockchain
console.log('Starting the Miner ...');
demoBlockchain.minePendingTransactions('fakeAddress'); // miningRewardAddress is a fake Address account named 'fakeAddress' 

// Check the balance of the fakeAddress
console.log('Balance of "fakeAddress" account is : ', demoBlockchain.getBalanceOfAddress('fakeAddress'));

// 2nd time because in minePendingTransactions() method we reset the Reset the pending Transaction Array
// Start the Miner to create block theses pending transaction & store them in our Blockchain
console.log('Starting the miner again...');
demoBlockchain.minePendingTransactions('fakeAddress'); // miningRewardAddress is a fake Address account named 'fakeAddress' 

// Check the balance of the fakeAddress
console.log('Balance of "fakeAddress" account is :', demoBlockchain.getBalanceOfAddress('fakeAddress'));
