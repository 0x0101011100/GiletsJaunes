console.log("Create Wallet");

var express = require('express');
var app = express();
var request = require('request');
var bodyParser = require('body-parser');
var port = 8080;
var bitcore = require('bitcore-lib');

app.use(bodyParser.urlencoded(
	{
		extended:true // no deprecated error
	}
));

// Using JSON
app.use(bodyParser.json());

/*
request({
		url:"https://blockchain.info/stats?format=json",
		json:true
	}, function (error,response,body) {
		btcPrice = body.market_price_usd;
		btcBlocks = body.n_blocks_total;
});
*/

app.get("/", function(req,res) {
	res.sendFile(__dirname + "/index.html");
});

app.post("/wallet", function(req,res) {
	var brainsrc = req.body.brainsrc;
	console.log(brainsrc);
	
	var input = new Buffer(brainsrc);
	var hash = bitcore.crypto.Hash.sha256(input);
	var bigNumber = bitcore.crypto.BN.fromBuffer(hash);
	var privateKey = new bitcore.PrivateKey(bigNumber).toWIF(); // Wallet Import Format
	var address = new bitcore.PrivateKey(bigNumber).toAddress();
	
	res.send("The Brain Waller of " + brainsrc + "<br/>Address : " + address + "<br/>Private Key : " + privateKey);
});

// Verify wallet
// https://blockchain.info/address/<address>


app.listen(port, function() {
	console.log("Listening on port : " + port);
});