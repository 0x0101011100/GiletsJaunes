console.log("Create Wallet & Converter BTC/USD");

var express = require('express');
var app = express();
var request = require('request');
var bodyParser = require('body-parser');
var port = 8080;
var bitcore = require('bitcore-lib');

// www.blocktrail.com - https://dev.btc.com
var user = "youremail@provider.com";
var password = "YourPassword";
var keyLabel = "YourKeyLabel";
var apiKey = "YourAPIKey";
var apiSecret = "YourSecretKey";

app.use(bodyParser.urlencoded(
	{
		extended:true // no deprecated error
	}
));

// Using JSON
app.use(bodyParser.json());

// Use ejs view engine
app.set("view engine", "ejs");

// For Resources loading like images
app.use(express.static( "public"));

// Brain Wallet function
function brainWallet(userInput, callback) {
	
	var input = new Buffer(userInput);
	var hash = bitcore.crypto.Hash.sha256(input);
	var bigNumber = bitcore.crypto.BN.fromBuffer(hash);
	var privateKey = new bitcore.PrivateKey(bigNumber).toWIF(); // Wallet Import Format
	var address = new bitcore.PrivateKey(bigNumber).toAddress();

	callback(privateKey,address);
	
};

// Callback function to request Currency Price
function getPrice(returnPrice) {
	request({
		url: "https://api.bitfinex.com/v1/ticker/btcusd",
		json:true
		// https://btc-e.com/api/3/ticker/btc_usd
	}, function(err,res,body) {
		returnPrice(body.last_price);
	});
};

// HOME Route
app.get("/", function(req,res) {
	
	getPrice(function(lastPrice) {
		res.render("index", {
			lastPrice : lastPrice
		});
	});
});

// CREATE WALLET Route
app.get("/createwallet", function(req,res) {	
	getPrice(function(lastPrice) {
		res.render("createwallet", {
			lastPrice : lastPrice
		});
	});
});

// CONVERTER Route
app.get("/converter", function(req,res) {
	getPrice(function(lastPrice) {
		res.render("converter", {
			lastPrice : lastPrice
		});
	});
});


// WALLET Route
app.post("/wallet", function(req,res) {
	var brainsrc = req.body.brainsrc;
	console.log(brainsrc);
	
	// Call brain Wallet
	brainWallet(brainsrc, function(privateKey, address) {
		res.send("The Brain Waller of " + brainsrc + "<br/>Address : " + address + "<br/>Private Key : " + privateKey);
	});
});


app.listen(port, function() {
	console.log("Listening on port : " + port);
});