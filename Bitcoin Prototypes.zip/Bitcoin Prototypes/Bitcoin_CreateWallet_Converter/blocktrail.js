var Key = "YourKey";
var Secret = "YourSecretKey";

// Import Blocktrail-sdk
blocktrail = require("blocktrail-sdk");

// Client creation
client = blocktrail.BlocktrailSDK(
	{
		apiKey: Key,
		apiSecret: Secret,
		network: "BTC",
		testnet: false
	}
);

// Connect to the created Wallet
client.initWallet("myWallet", "myPass",

	function(error, wallet) {
		// Display Wallet info
		//console.log(wallet);
		
		//Get new address for separate payment
		wallet.getNewAddress(function(error,address) {
			console.log(address);
		});
	}
);

// TO SAVE when you create a Wallet (Response from backupinfo callback)
// Example :
var encryptedPrimarySeed = "library farm achieve dynamic unique actress system tonight bamboo amount abandon absorb abandon gas identify convince stamp apart split miracle effort smile vivid problem economy flat fit inch margin desk resist cereal cousin primary input zoo become margin tragic stadium nothing trash flavor seat sorry hotel slogan private step vintage middle scare poem near setup spare traffic scorpion mechanic action";
var backupSeed = "release rocket hand retreat exit wealth pistol typical exile copper peanut elbow this aware jazz thunder dawn nephew garage price custom net clump monitor";
var recoveryEncryptedSecret="library finger wet clock boss stadium arrest march witness session abandon accident permit medal coil october panda orange phone find tissue because mom defense please ski paddle case barrel achieve uniform pluck obtain cable nasty giggle pumpkin awkward arch long happy comic practice veteran fan novel air floor moon allow ketchup another label celery sorry sample behind donate symptom impulse";
var encryptedSecret="library father weird stumble play region initial cloud trade session abandon absurd embody task forward multiply gasp stick stand diamond orient spike treat dismiss earth armor bike tiny permit eyebrow circle category april salon style movie barrel kiwi knife hawk lobster rival distance flower dinner search know box scene blossom never strong joy person shine ozone about fly exist dinner";
