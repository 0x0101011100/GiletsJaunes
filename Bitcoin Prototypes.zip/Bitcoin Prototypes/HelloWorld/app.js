console.log("Hello world");

var http = require('http');
var request = require('request');

http.createServer( function(req, res) {
	
	//request is a new visitor
	request({
		url:"https://blockchain.info/stats?format=json",
		json:true
	}, function (error,response,body) {
		//console.log("Error : "+ error);
		//console.log(response);
		console.log(body.market_price_usd);
	});
	
	console.log("Hi, i'm a new bitcoin user" + req.url);
	res.end("Bitcoin app");
	
}).listen(8080);
