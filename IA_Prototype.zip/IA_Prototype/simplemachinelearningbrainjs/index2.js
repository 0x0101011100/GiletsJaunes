const brain = require('brain.js');
const data = require('./data.json');

// Using Brain.js LSTM
const network = new brain.recurrent.LSTM();

const trainingData = data.map(item => ({
	input:item.text,
	output:item.category
}));

network.train(trainingData, {
	iteration: 2000
});

//const output = network.run('I fixed the power supply');

//const output = network.run('I fixed the power supply');
const output = network.run('what is your name ?');
console.log('Category chosen :' + output);








