// Run several time to see that the code compute each time a new Probability for a fixed Experimental Test value
const brain = require('brain.js');

const network = new brain.NeuralNetwork();

/* EX#1
network.train([ // Feed w/ DB
	{input: [0,0,0], output: [0] },
	{input: [0,0,1], output: [0] },
	{input: [0,1,1], output: [0] },
	{input: [1,0,1], output: [1] },
	{input: [1,1,1], output: [1] }
]);
*/

/* Baseball Team
network.train([ // Feed w/ DB
	{input: [1,2], output: [1] }, // Team 2 wins
	{input: [1,3], output: [1] }, // Team 3 wins
	{input: [2,3], output: [0] }, // Team 2 wins
	{input: [2,4], output: [1] } // Team 4 wins
]);
*/

// Proto#2
network.train([ // Feed w/ DB
	{input: [1,2], output: [1] }, // Team 2 wins
	{input: [1,3], output: [1] }, // Team 3 wins
	{input: [2,3], output: [0] }, // Team 2 wins
	{input: [2,4], output: [1] }, // Team 4 wins
	{input: [1,2], output: [0] }, // Team 1 wins
	{input: [1,3], output: [0] }, // Team 1 wins
	{input: [3,4], output: [1] } // Team 4 wins
]);

/* EX#1
const output = network.run([1,1,0]); // Experimental Test value
*/

// Baseball Team
const output = network.run([1,4]); // Experimental Test value

console.log('Probability : ' + output);


// Feeding

// const output = network.run([1,0,0]);
// node index.js
// const output = network.run([0,0,0]);
// node index.js
// const output = network.run([0,1,1]);
// node index.js
// const output = network.run([1,1,1]);
// node index.js
// const output = network.run([1,1,0]);
// node index.js



